<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 20-3-2019
 * Time: 12:51
 */
echo "<h1>Garage update auto 2 </h1>";
echo "<h2>Dit formulier wordt gebruikt om de autogegevens te wijzigen in de tabel auto van de database garage</h2>";

//autoid uit het formulier halen
$id = $_POST ["id"];

//autogegevens uit de tabel halen
require_once "gar-connect.php";

$autos = $conn->prepare("select id, automerk, autotype, autokenteken, kilometerstand, klantid from auto where id = :id");

$autos->execute(["id"=> $id]);

//autogegevens in een nieuw formulier laten zien
echo "<form action='gar-update-auto3.php' method='post'>";
foreach ($autos as $auto)
{
    //autoid mag niet gewijzigd worden
    echo "<input type='hidden' name='id' value='".$auto["id"]."'> Het ID is " . $auto["id"] . " (Uw ID kunt u niet wijzigen) <br />";

    echo "Vul hier in het nieuwe automerk: <input type='text' name='automerkvak'> Het oude automerk was " .$auto["automerk"]."<br />";

    echo "Vul hier in het nieuwe autotype: <input type='text' name = 'autotypevak'> Het oude autotype was " .$auto["autotype"]."<br />";

    echo "Vul hier in het nieuwe autokenteken: <input type='text' name = 'autokentekenvak'> Het oude kenteken was " .$auto["autokenteken"]."<br />";

    echo "Vul hier in de nieuwe kilometerstand: <input type='text' name = 'kilometerstandvak'> De oude kilometerstand was " .$auto["kilometerstand"]."<br />";
}
echo "<input type='submit'>";

