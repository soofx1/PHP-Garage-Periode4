<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 30-1-2019
 * Time: 15:22
 */

$id = NULL;
$klantnaam = $_POST ["klantnaamvak"];
$klantadres = $_POST ["klantadresvak"];
$klantpostcode = $_POST ["klantpostcodevak"];
$klantplaats = $_POST ["klantplaatsvak"];

//Klantgegevens uit het formulier halen
require_once "gar-connect.php";
$sql = $conn->prepare("insert into klant values (:id, :klantnaam, :klantadres, :klantpostcode, :klantplaats)");

$sql->bindParam(":id", $id);
$sql->bindParam(":klantnaam", $klantnaam);
$sql->bindParam(":klantadres", $klantadres);
$sql->bindParam(":klantpostcode", $klantpostcode);
$sql->bindParam(":klantplaats", $klantplaats);

$sql->execute();

echo "<h1>Garage create klant 2 </h1>";
echo "De klant is toegevoegd <br /> <br />";
echo "Een klant toevoegen aan de tabel klant in de <br /> database garage. <br /> <br />";
echo "<a href='gar-menu.html'> Terug naar het menu </a>";