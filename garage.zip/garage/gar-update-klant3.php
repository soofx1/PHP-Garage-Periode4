<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 12-2-2019
 * Time: 12:47
 */
echo "<h1>Garage update klant 3</h1>";
echo "<p>Klantgegevens wijzigen in de tabel klant van de database garage.</p>";

//klant gegevens uit het formulier halen
$id = $_POST ["id"];
$klantnaam = $_POST ["klantnaamvak"];
$klantadres = $_POST ["klantadresvak"];
$klantpostcode = $_POST ["klantpostcodevak"];
$klantplaats = $_POST ["klantplaatsvak"];

//updaten klantgegevens
require_once "gar-connect.php";

$sql = $conn->prepare(
    "update klant set klantnaam = :klantnaam, klantadres = :klantadres, klantpostcode = :klantpostcode, klantplaats = :klantplaats where id = :id");

$sql->bindParam(":id", $id);
$sql->bindParam(":klantnaam", $klantnaam);
$sql->bindParam(":klantadres", $klantadres);
$sql->bindParam(":klantpostcode", $klantpostcode);
$sql->bindParam(":klantplaats", $klantplaats);

$sql->execute();

echo "De klant is gewijzigd. <br />";
echo "<a href='gar-menu.html'> Terug naar het menu </a>";
