<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 31-1-2019
 * Time: 13:54
 */

require_once "gar-connect.php";

$klanten = $conn->prepare("select id, klantnaam, klantadres, klantpostcode, klantplaats from klant");

$klanten->execute();

echo "<h1>Garage read klant</h1>";
echo "<p>Dit zijn alle gegevens uit de tabel klanten van de database garage</p></br>";

echo "<table>";
foreach ($klanten as $klant)
{
    echo "<tr>";
    echo "<td>" .   $klant["id"]       .   "</td>";
    echo "<td>" .   $klant["klantnaam"]     .   "</td>";
    echo "<td>" .   $klant["klantadres"]    .   "</td>";
    echo "<td>" .   $klant["klantpostcode"] .   "</td>";
    echo "<td>" .   $klant["klantplaats"]   .   "</td>";
    echo "</tr>";
}

echo "</table>";
echo "</br><a href='gar-menu.html'>Terug naar het menu</a>";