<?php
/**
 * Created by PhpStorm.
 * User: Ludger_Jukema
 * Date: 27-3-2019
 * Time: 14:00
 */

require_once "gar-connect.php";

$link = $conn->prepare ("select klant.id, auto.id, klantnaam, automerk, autokenteken, autotype from klant, auto
where klant.id = auto.id");

$link->execute();

echo "<h1>Garage link auto met klant</h1>";
echo "<p>Dit zijn alle gegevens uit de database garage</p></br>";

echo "<table>";
foreach ($link as $linken)
{
    echo "<tr>";
    echo "<td>" .   $linken["automerk"]       .   "</td>";
    echo "<td>" .   $linken["autotype"]     .   "</td>";
    echo "<td>" .   $linken["klantnaam"]    .   "</td>";
    echo "</tr>";
}

echo "</table>";
echo "</br><a href='gar-menu.html'>Terug naar het menu</a>";