<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 21-3-2019
 * Time: 9:15
 */
echo "<h1>Garage delete auto 2</h1>";
echo "<p>Op id gegevens zoeken uit de tabel auto van de database garage zodat ze verwijderd kunnen worden.</p>";

//klantid uit het formulier halen
$id =$_POST ["id"];

//klantgegevens uit de tabel halen
require_once "gar-connect.php";

$autos = $conn->prepare("select auto.id, automerk, autotype, autokenteken, kilometerstand from auto where auto.id = :id");

$autos->execute(["id"=> $id]);

//klantgegevens laten zien
echo "<table>";
foreach ($autos as $auto);
{
    echo "<tr>";
    echo "<td>" . $auto ["id"];
    echo "<td>" . $auto ["automerk"];
    echo "<td>" . $auto ["autotype"];
    echo "<td>" . $auto ["autokenteken"];
    echo "<td>" . $auto ["kilometerstand"];
    echo "<tr>";
}
echo "</table><br />";

echo "<form action='gar-delete-auto3.php' method='post'>";
//id mag niet meer gewijzigd worden
echo "<input type='hidden' name='id' value=$id>";
//waarde 0 doorgeven als er niet gecheckt wordt
echo "<input type='hidden' name='verwijdervak' value='0'>";
echo "<input type='checkbox' name='verwijdervak' value='1'>";
echo "Verwijder deze auto. <br />";
echo "<input type='submit'>";
echo "</form>";