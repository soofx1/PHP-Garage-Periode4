<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 20-3-2019
 * Time: 14:09
 */
echo "<h1>Garage update Auto 3</h1>";
echo "<p>Autogegevens wijzigen in de tabel auto van de database garage.</p>";

//autogegevens uit het formulier halen
$id = $_POST ["id"];
$automerk = $_POST ["automerkvak"];
$autotype = $_POST ["autotypevak"];
$autokenteken = $_POST ["autokentekenvak"];
$kilometerstand = $_POST ["kilometerstandvak"];

//updaten autogegevens
require_once "gar-connect.php";

$sql = $conn->prepare(
    "update auto set automerk = :automerk, autotype = :autotype, autokenteken = :autokenteken, kilometerstand = :kilometerstand where id = :id");

$sql->bindParam(":id", $id);
$sql->bindParam(":automerkvak", $automerk);
$sql->bindParam(":autotypevak", $autotype);
$sql->bindParam(":autokentekenvak", $autokenteken);
$sql->bindParam(":kilometerstandvak", $kilometerstand);

$sql->execute();

echo "De auto is gewijzigd. <br />";
echo "<a href='gar-menu.html'> Terug naar het menu </a>";
