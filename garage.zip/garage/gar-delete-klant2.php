<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 14-2-2019
 * Time: 10:29
 */
echo "<h1>Garage delete klant 2</h1>";
echo "<p>Op klantid gegevens zoeken uit de tabel klanten van de database garage zodat ze verwijderd kunnen worden.</p>";

//klantid uit het formulier halen
$id =$_POST ["id"];

//klantgegevens uit de tabel halen
require_once "gar-connect.php";

$klanten = $conn->prepare("select id, klantnaam, klantadres, klantpostcode, klantplaats from klant where id = :id");

$klanten->execute(["id"=> $id]);

//klantgegevens laten zien
echo "<table>";
foreach ($klanten as $klant);
{
    echo "<tr>";
    echo "<td>" . $klant ["id"];
    echo "<td>" . $klant ["klantnaam"];
    echo "<td>" . $klant ["klantadres"];
    echo "<td>" . $klant ["klantpostcode"];
    echo "<td>" . $klant ["klantplaats"];
    echo "<tr>";
}
echo "</table><br />";

echo "<form action='gar-delete-klant3.php' method='post'>";
//klantid mag niet meer gewijzigd worden
echo "<input type='hidden' name='id' value=$id>";
//waarde 0 doorgeven als er niet gecheckt wordt
echo "<input type='hidden' name='verwijdervak' value='0'>";
echo "<input type='checkbox' name='verwijdervak' value='1'>";
echo "Verwijder deze klant. <br />";
echo "<input type='submit'>";
echo "</form>";