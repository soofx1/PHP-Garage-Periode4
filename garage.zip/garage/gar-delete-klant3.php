<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 14-2-2019
 * Time: 10:50
 */
echo "<h1>Garage delete klant 3</h1>";
echo "<p>Op klantid gegevens zoeken uit de tabel klanten van de database garage zodat ze verwijderd kunnen worden.</p>";

//gegevens uit het formulier halen
$id = $_POST["id"];
$verwijderen = $_POST["verwijdervak"];

//klantgegevens verwijderen
if ($verwijderen)
{
    require_once "gar-connect.php";

    $sql = $conn->prepare("delete from klant where id = :id");
    $sql->execute(["id" => $id]);

    echo "<p>De gegevens zijn verwijderd</p>";
}
else
{
    echo "<p>De gegevens zijn niet verwijderd</p>";
}

echo "<a href='gar-menu.html'>Terug naar het menu.</a>";