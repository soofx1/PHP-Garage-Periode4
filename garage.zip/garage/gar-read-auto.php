<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 21-2-2019
 * Time: 9:54
 */
require_once "gar-connect.php";

$autos = $conn->prepare("select id, automerk, autotype, autokenteken, kilometerstand, klantid from auto");

$autos ->execute();

echo "<h1>Garage read auto</h1>";
echo "<p>Dit zijn alle gegevens uit de tabel auto van de database garage</p></br>";

echo "<table>";
foreach ($autos as $auto)
{
    echo "<tr>";
    echo "<td>" .   $auto["id"]       .   "</td>";
    echo "<td>" .   $auto["automerk"]     .   "</td>";
    echo "<td>" .   $auto["autotype"]    .   "</td>";
    echo "<td>" .   $auto["autokenteken"]    .   "</td>";
    echo "<td>" .   $auto["kilometerstand"] .   "</td>";
    echo "<td>" .   $auto["klantid"]   .   "</td>";
    echo "</tr>";
}

echo "</table>";
echo "</br><a href='gar-menu.html'>Terug naar het menu</a>";