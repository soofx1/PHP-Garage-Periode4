<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 5-2-2019
 * Time: 14:16
 */

echo "<h1>Garage zoek op klantid 2</h1>";
echo "<p>Op klantid gegevens zoeken uit de tabel klanten van de database garage</p>";

// klantid uit het formulier halen
$id = $_POST ["id"];

// klantgegevens uit de tabel halen

require_once "gar-connect.php";

$klanten = $conn->prepare("select id, klantnaam, klantadres, klantpostcode, klantplaats from klant where id = :id");
$klanten->bindParam('klantid', $id);

$klanten->execute();

// klantgegevens laten zien
echo "<table>";

foreach ($klanten as $klant) {
    echo "<tr>";
    echo "<td>" . $klant["id"] . "</td>";
    echo "<td>" . $klant["klantnaam"] . "</td>";
    echo "<td>" . $klant["klantadres"] . "</td>";
    echo "<td>" . $klant["klantpostcode"] . "</td>";
    echo "<td>" . $klant["klantplaats"] . "</td>";
    echo "</tr>";
}
echo "</table>";

echo "</table><br />";
echo "<a href='gar-menu.html'> Terug naar het menu </a>";
