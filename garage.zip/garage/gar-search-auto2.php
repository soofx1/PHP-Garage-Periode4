<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 21-2-2019
 * Time: 10:04
 */
echo "<h1>Garage zoek op kenteken 2</h1>";
echo "<p>Op kenteken gegevens zoeken uit de tabel auto van de database garage</p>";

// autoid uit het formulier halen
$autokenteken = $_POST ["autokenteken"];

// autogegevens uit de tabel halen

require_once "gar-connect.php";

$autos = $conn->prepare("select id, automerk, autotype, autokenteken, kilometerstand, klantid from auto where autokenteken = :autokenteken");
$autos->bindParam('autokenteken', $autokenteken);
$autos->execute();

// autogegevens laten zien
echo "<table>";
foreach ($autos as $auto) {
    echo "<tr>";
    echo "<td>" . $auto["id"] . "</td>";
    echo "<td>" . $auto["automerk"] . "</td>";
    echo "<td>" . $auto["autotype"] . "</td>";
    echo "<td>" . $auto["autokenteken"] . "</td>";
    echo "<td>" . $auto["kilometerstand"] . "</td>";
    echo "<td>" . $auto["klantid"] . "</td>";
    echo "</tr>";
}
echo "</table>";

echo "</table><br />";
echo "<a href='gar-menu.html'> Terug naar het menu </a>";
