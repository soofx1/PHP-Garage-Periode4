<?php
/**
 * Created by PhpStorm.
 * User: Sophia_Jukema
 * Date: 7-2-2019
 * Time: 17:04
 */
echo "<h1>Garage update klant 2 </h1>";
echo "<h2>Dit formulier wordt gebruikt om klantgegevens te wijzigen in de tabel klant van de database garage</h2>";

//klantid uit het formulier halen
$id = $_POST ["id"];

//klantgegevens uit de tabel halen
require_once "gar-connect.php";

$klanten = $conn->prepare("select id, klantnaam, klantadres, klantpostcode, klantplaats from klant where id = :id");

$klanten->execute(["id"=> $id]);

//klantgegevens in een nieuw formulier laten zien
echo "<form action='gar-update-klant3.php' method='post'>";
foreach ($klanten as $klant)
{
    //klantid mag niet gewijzigd worden
    echo "<input type='hidden' name='id' value='".$klant["id"]."'> ID = " . $klant["id"] . " <br />";

    echo "klantnaam: <input type='text' name='klantnaamvak'> Naam = " .$klant["klantnaam"]."<br />";

    echo "klantadres: <input type='text' name = 'klantadresvak'> Adres = " .$klant["klantadres"]."<br />";

    echo "klantpostcode: <input type='text' name = 'klantpostcodevak'> Postcode = " .$klant["klantpostcode"]."<br />";

    echo "klantplaats: <input type='text' name = 'klantplaatsvak'> Plaats = " .$klant["klantplaats"]."<br />";
}
echo "<input type='submit'>";

