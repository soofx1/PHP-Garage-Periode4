<?php
/**
 * Created by PhpStorm.
 * User: Ludger_Jukema
 * Date: 14-2-2019
 * Time: 13:06
 */

$id = NULL;
$automerk = $_POST ["automerkvak"];
$autotype = $_POST ["autotypevak"];
$autokenteken = $_POST ["autokentekenvak"];
$kilometerstand = $_POST ["autokmstandvak"];
$klantid = $_POST["klantidvak"];

//Klantgegevens uit het formulier halen
require_once "gar-connect.php";

$sql = $conn->prepare("insert into auto (automerk, autotype, autokenteken, kilometerstand, klantid) values (:automerk, :autotype, :autokenteken, :kilometerstand, :klantid)");

$sql->bindParam(":automerk", $automerk);
$sql->bindParam(":autotype", $autotype);
$sql->bindParam(":autokenteken", $autokenteken);
$sql->bindParam(":kilometerstand", $kilometerstand);
$sql->bindParam(":klantid", $klantid);

$sql->execute();

echo "<h1>Garage create auto 2 </h1>";
echo "De auto is toegevoegd <br /> <br />";
echo "Een auto toevoegen aan de tabel auto in de <br /> database garage. <br /> <br />";
echo "<a href='gar-menu.html'> Terug naar het menu </a>";